# 🎌 AnimeSama App

Application Android WebView pour anime-sama.to

## Fonctionnalités
- Plein écran, sans barre de navigateur
- Bouton 🔗 pour changer l'URL facilement
- Bouton ← retour navigation
- Pull-to-refresh
- URL mémorisée entre les sessions

## URL par défaut
`https://anime-sama.to/`

## Changer l'URL par défaut (dans le code)
Modifie `DEFAULT_URL` dans `MainActivity.java` ligne ~20
